package com.example.byo_driver

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
